import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyForm(),
    );
  }
}

class MyForm extends StatefulWidget {
  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  String? civilite;
  String nom = "";
  String prenom = "";
  String? specialite;
  List<String> matieres = [];
  List<DataEntry> dataEntries = [];

  List<String> matieresEnMemoire = ["Mathématiques", "Physique", "Chimie", "Informatique"];
  List<String> specialitesEnMemoire = ["Informatique", "Electrique", "Spécialité 4"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter Form'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            DropdownButton<String>(
              hint: Text("Select Title"),
              value: civilite,
              onChanged: (value) {
                setState(() {
                  civilite = value;
                });
              },
              items: ["Mr.", "Mrs.", "Miss"].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),

            TextFormField(
              decoration: InputDecoration(labelText: 'Last Name'),
              onChanged: (value) {
                setState(() {
                  nom = value;
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'First Name'),
              onChanged: (value) {
                setState(() {
                  prenom = value;
                });
              },
            ),
            DropdownButtonFormField<String>(
              value: specialite,
              decoration: InputDecoration(labelText: 'Specialty'),
              onChanged: (String? value) {
                setState(() {
                  specialite = value;
                });
              },
              items: specialitesEnMemoire.map((String specialite) {
                return DropdownMenuItem<String>(
                  value: specialite,
                  child: Text(specialite),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            Text('Select Subjects:'),
            Column(
              children: matieresEnMemoire.map((String matiere) {
                return CheckboxListTile(
                  title: Text(matiere),
                  value: matieres.contains(matiere),
                  onChanged: (bool? value) {
                    setState(() {
                      if (value != null) {
                        if (value) {
                          matieres.add(matiere);
                        } else {
                          matieres.remove(matiere);
                        }
                      }
                    });
                  },
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                dataEntries.add(DataEntry(
                  civilite: civilite,
                  nom: nom,
                  prenom: prenom,
                  specialite: specialite,
                  matieres: matieres,
                ));
                setState(() {
                  civilite = null;
                  nom = "";
                  prenom = "";
                  specialite = null;
                  matieres = [];
                });
              },
              child: Text('Add to List'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => DataListPage(dataEntries: dataEntries),
                  ),
                );
              },
              child: Text('Show List'),
            ),
          ],
        ),
      ),
    );
  }
}

class DataEntry {
  final String? civilite;
  late final String nom;
  late final String prenom;
  late final String? specialite;
  final List<String> matieres;

  DataEntry({
    required this.civilite,
    required this.nom,
    required this.prenom,
    required this.specialite,
    required this.matieres,
  });
}

class DataListPage extends StatefulWidget {
  final List<DataEntry> dataEntries;

  DataListPage({
    required this.dataEntries,
  });

  @override
  _DataListPageState createState() => _DataListPageState();
}

class _DataListPageState extends State<DataListPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Data List'),
      ),
      body: ListView.builder(
        itemCount: widget.dataEntries.length,
        itemBuilder: (context, index) {
          final dataEntry = widget.dataEntries[index];
          return Card(
            child: ListTile(
              title: Text('Title: ${dataEntry.civilite}'),
              subtitle: Text('Last Name: ${dataEntry.nom}\nFirst Name: ${dataEntry.prenom}\nSpecialty: ${dataEntry.specialite}\nSubjects: ${dataEntry.matieres.join(", ")}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      widget.dataEntries.removeAt(index);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Data removed'),
                          duration: Duration(seconds: 2),
                        ),
                      );
                      setState(() {});
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () {
                      _showEditDialog(context, index);
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _showEditDialog(BuildContext context, int index) {
    // Initialisez specialitesEnMemoire avec les options de spécialité appropriées
    List<String> specialitesEnMemoire = ["Informatique", "Electrique", "Spécialité 4"];
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Data'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  initialValue: widget.dataEntries[index].nom,
                  onChanged: (value) {
                    widget.dataEntries[index].nom = value;
                  },
                  decoration: InputDecoration(labelText: 'Last Name'),
                ),
                TextFormField(
                  initialValue: widget.dataEntries[index].prenom,
                  onChanged: (value) {
                    widget.dataEntries[index].prenom = value;
                  },
                  decoration: InputDecoration(labelText: 'First Name'),
                ),
                DropdownButtonFormField<String>(
                  value: widget.dataEntries[index].specialite,
                  onChanged: (String? value) {
                    setState(() {
                      widget.dataEntries[index].specialite = value;
                    });
                  },
                  items: specialitesEnMemoire.map((String specialite) {
                    return DropdownMenuItem<String>(
                      value: specialite,
                      child: Text(specialite),
                    );
                  }).toList(),
                  decoration: InputDecoration(labelText: 'Specialty'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }
}
